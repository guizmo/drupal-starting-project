This module provides an overview of all the imagecache presets in use on this 
site, as well as a number of samples used to test if everything is working as 
expected.

Sample images are provided to illustrate a number of the sample presets.
Each image shown should match the one next to it. 
Where they don't match illustrates a current weakness in the system or the code 
coverage.

