Additional actions for imagecache processing - a bundle

This release was built against
imagecache: DRUPAL-5--2-0
imageapi: DRUPAL-5--1-1

As retrieved 2008-05-27

... anything else may encounter mixed results
